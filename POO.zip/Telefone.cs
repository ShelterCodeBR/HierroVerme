using System;

class Telefone{
  string marca;
  double altura;
  string operador = "Sem Operadora";
  int numero = 0;
  double massa;
  int volumeAudio = 0;
  bool ligado;

  public Telefone(string marca, double altura, string operador, int numero, double massa){
    this.marca = marca;
    this.altura = altura;
    this.operador = operador;
    this.numero = numero;
    this.massa = massa;
  }

  public void Ligar(){
    Console.WriteLine("Ligando Celular");
    ligado = true;
  }

  public void Desligar(){
    Console.WriteLine("Desligando Celular");
    ligado = false;
  }

  public void AumentarVolume(){
    Console.WriteLine("Mais uma unidade de Volume");
    volumeAudio++;
  }
  public void DiminuirVolume(){
    Console.WriteLine("Menos uma unidade de Volume");
    volumeAudio--;
  }


  
  }
