using System;

class Program {
  public static void Main (string[] args) {
    Telefone iphone = new Telefone("iphone", 0.15, "Vivo", 950323858, 0.2);
    iphone.Ligar();
  }
}